# data handling
import numpy as np
# mushroom
from mushroom_rl.algorithms.value import TrueOnlineSARSALambda
from mushroom_rl.core import Core, Logger
from mushroom_rl.environments import PuddleWorld
from mushroom_rl.features import Features
from mushroom_rl.features.basis import FourierBasis, GaussianRBF
from mushroom_rl.features.tiles import Tiles
from mushroom_rl.policy import EpsGreedy
from mushroom_rl.utils.dataset import compute_J, compute_episodes_length
from mushroom_rl.utils.plot import plot_mean_conf
from mushroom_rl.utils.parameters import Parameter
# utils
from joblib import Parallel, delayed
# visualization
from tqdm import trange
import matplotlib.pyplot as plt

import mushroom_rl
assert mushroom_rl.__version__ == "1.9.2", "Please upgrade MushroomRL to 1.9.2! Use pip install mushroom==1.9.2!"

def experiment(params, seed, exp_id = None):

    n_epochs = params["n_epochs"]
    n_steps = params["n_steps"]
    n_episodes_test = params["n_episodes_test"]
    render = params["render"]
    alpha = params["alpha"]
    func_approx = params["func_approx"]
    
    np.random.seed(seed)

    # Logger
    logger = Logger('PuddleWorld_TrueOnlineSARSALambda', results_dir=None)
    logger.strong_line()
    logger.info('Environment: PuddleWorld')
    logger.info('Experiment Algorithm: TrueOnlineSARSALambda')
    logger.info(f'Function Approximator: {func_approx}')

    # MDP
    mdp = PuddleWorld(horizon=1000)

    # Policy
    epsilon = Parameter(value=0.1)
    pi = EpsGreedy(epsilon=epsilon)

    # Function Approximator
    if func_approx == "tiles": 
        # [YOUR CODE!]
        pass
    elif func_approx == "gaussian":
        # [YOUR CODE!]
        pass
    elif func_approx == "fourier":
        # [YOUR CODE!]
        pass
    elif func_approx == "raw":
        # [YOUR CODE!]
        pass

    approximator_params = dict(input_shape=(features.size,),
                               output_shape=(mdp.info.action_space.n,),
                               n_actions=mdp.info.action_space.n)
    algorithm_params = {'learning_rate': learning_rate,
                        'lambda_coeff': params["lambda_coeff"]}

    agent = TrueOnlineSARSALambda(mdp.info, pi,
                                  approximator_params=approximator_params,
                                  features=features, **algorithm_params)

    # Algorithm
    core = Core(agent, mdp)
    
    # Training & Evaluating Loop
    Js  = []
    ELs = []

    # [YOUR CODE!]

    if exp_id == 0:
        core.evaluate(n_episodes=1, render=True, quiet=True)

    return Js, ELs


if __name__ == '__main__':
    n_experiment = 30

    seeds = np.random.randint(0, 1e5, size=(n_experiment,)) 

    func_approx = ["raw", "fourier", "gaussian", "tiles"]

    params = {
        "n_epochs": 10,
        "n_steps": 5000,
        "n_episodes_test": 5,
        "render": False,
        "alpha": .1,    # [TUNE PARAMETER!]: Modify the learning rate for each algorithm (if needed)!
        "n_harmonics":  # [TUNE PARAMETER!],   
        "n_centers":    # [TUNE PARAMETER!],     
        "n_tilings":    # [TUNE PARAMETER!],  
        "n_tiles":      # [TUNE PARAMETER!],      
        "lambda_coeff": 0.9,
    }

    J = {}
    EL = {}
    for f in func_approx:
        
        params["func_approx"] = f
        
        data = Parallel(n_jobs=-1)(delayed(experiment)(params, seeds[i], exp_id = i) for i in range(n_experiment))

        J[f] = np.array([j[0] for j in data])
        EL[f] = np.array([j[1] for j in data])
    
    # Plot Objective
    fig = plt.figure()
    ax = fig.gca()
    colors = plt.rcParams['axes.prop_cycle'].by_key()['color']

    for i, (key, value) in enumerate(J.items()):
        plot_mean_conf(value, ax, color=colors[i], label=key)

    plt.legend(loc=4)
    plt.xlabel("Epochs")
    plt.ylabel("Average Return")
    plt.savefig("J_func_approx.png")

    # Plot Episode Length
    fig = plt.figure()
    ax = fig.gca()

    for i, (key, value) in enumerate(EL.items()):
        plot_mean_conf(value, ax, color=colors[i], label=key)

    plt.legend(loc=4)
    plt.xlabel("Epochs")
    plt.ylabel("Episode Length")
    plt.savefig("EL_func_approx.png")