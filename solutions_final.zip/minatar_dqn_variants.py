# utils
from joblib import Parallel, delayed
import os

# deeplearning framework
from torch import seed
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

# mushroom
from mushroom_rl.core import Core, Logger
from mushroom_rl.environments import *
from mushroom_rl.policy import EpsGreedy
from mushroom_rl.utils.parameters import Parameter, LinearParameter
from mushroom_rl.utils.dataset import compute_J, compute_episodes_length, get_init_states
from mushroom_rl.algorithms.value.dqn import DQN, DoubleDQN, AveragedDQN, MaxminDQN
from mushroom_rl.approximators.parametric.torch_approximator import *
from mushroom_rl.utils.plot import plot_mean_conf
# hw2
from hw2.algorithms.value import DQNwoReplayBuffer, DoubleMaxminDQN, NaiveDQN
from hw2.utils.argparser import argparser
from hw2.environments import MinAtar

# visualization
import matplotlib.pyplot as plt
import wandb

class QConvNetwork(nn.Module):
    def __init__(self, input_shape, output_shape, n_features, **kwargs):
        super().__init__()

        n_input = input_shape[0]
        n_output = output_shape[0]

        # One hidden 2D convolution layer:
        #   in_channels: variable
        #   out_channels: 16
        #   kernel_size: 3 of a 3x3 filter matrix
        #   stride: 1
        self.conv = nn.Conv2d(n_input, 16, kernel_size=3, stride=1)

        # Final fully connected hidden layer:
        #   the number of linear unit depends on the output of the conv
        #   the output consist 128 rectified units
        def size_linear_unit(size, kernel_size=3, stride=1):
            return (size - (kernel_size - 1) - 1) // stride + 1

        num_linear_units = size_linear_unit(10) * size_linear_unit(10) * 16
        self.fc_hidden = nn.Linear(in_features=num_linear_units, out_features=n_features[0])

        # Output layer:
        self.output = nn.Linear(in_features=n_features[0], out_features=n_output)
    
    # NOTE: atleast_1d is the correct way to remove the warning of the mismatch in dims but the warning does not harm the performance, so you can ignore it
    def forward(self, state, action=None):
        # Rectified output from the first conv layer
        q = torch.relu(self.conv(state.float())) #/ 255.
        q = torch.relu(self.fc_hidden(q.view(state.shape[0], -1)))
        q = self.output(q)

        if action is None:
            return torch.atleast_1d(q)
        else:
            q_acted = torch.squeeze(q.gather(1, action.long()))
            return torch.atleast_1d(q_acted)
        
# Implement the compute_V function to compute the estimated value function at the initial states.
# Follow the Deep Q-Learning practical session to implement this function.
def compute_V(dataset, q):
    
    '''
    Args:
        dataset (list): the dataset to consider;
        q (torch.nn.module): the q approximator.

    Returns:
        The approximated value of initial state of each episode in the dataset.

    '''
    vs = list()

    initial_states = get_init_states(dataset)
    for v0 in initial_states:        
        v = np.max(q.predict(np.expand_dims(v0, axis=0)))
        vs.append(v)

    if len(vs) == 0:
        return [0.]
    return vs


def run(pi, agent_class, mdp, params, approximator_params, num_epochs=100, n_steps=1000, n_episodes_test=5, seed=1, exp_name = None, log_dir = None, exp_id = 0):
    # wandb.init(name = "seed_"+str(seed), project = "RLCourse26_Assignment2", group = mdp.env_name + "_final", job_type=agent_class.__name__ if exp_name is None else exp_name, entity='superstudent', config=params)
    np.random.seed(seed)

    single_logger = Logger(f"seed_{exp_id if seed is None else seed}", results_dir=log_dir, log_console=True)
    log_dir = single_logger.path

    
    epsilon = LinearParameter(params['eps'], threshold_value = params['final_eps'], n=params['exploration_steps'])
    epsilon_test = Parameter(value=params['eps_test'])
    policy = pi(epsilon=epsilon)
    
    algorithm_params = dict(
                            approximator_params = approximator_params,
                            initial_replay_size = params["initial_replay_size"],
                            max_replay_size = params["max_replay_size"],
                            batch_size = params["batch_size"],
                            target_update_frequency = params["target_update_frequency"] // params['train_frequency'],
                            )
    
    # NOTE: removing the unneccessary arguments for NaiveDQN
    if agent_class.__name__ == "NaiveDQN":
        del algorithm_params["initial_replay_size"]
        del algorithm_params["max_replay_size"]
        del algorithm_params["target_update_frequency"]
    
    if params["n_approximators"] > 1:
        agent = agent_class(mdp.info, policy, TorchApproximator, params["n_approximators"], **algorithm_params)
    else:
        agent = agent_class(mdp.info, policy, TorchApproximator, **algorithm_params)


    core = Core(agent, mdp)

    Js = []
    ELs = []
    Vs = []

    core.learn(n_steps=params["initial_replay_size"], n_steps_per_fit=params["initial_replay_size"], quiet=False)

    policy.set_epsilon(epsilon_test)
    dataset = core.evaluate(n_episodes=n_episodes_test, render=False)
    J = compute_J(dataset, mdp.info.gamma)
    EL = compute_episodes_length(dataset)
    V = compute_V(dataset, policy.get_q())
    Js.append(np.mean(J))
    ELs.append(np.mean(EL))
    Vs.append(np.mean(V))
    single_logger.epoch_info(0, J=np.mean(J), EL=np.mean(EL), V=np.mean(V))
    # wandb.log({'average_return': np.mean(J), 'episode_length': np.mean(EL), 'value_estimate': np.mean(V)})

    for ep in tqdm(range(num_epochs)):
        core.learn(n_steps=n_steps, n_steps_per_fit=params['train_frequency'], quiet=False)
        policy.set_epsilon(epsilon_test)
        dataset = core.evaluate(n_episodes=n_episodes_test, render=False, quiet=True) #(exp_id == 0 and (ep + 1)%10 == 0)
        J = compute_J(dataset, mdp.info.gamma) # mdp.info.gamma
        EL = compute_episodes_length(dataset)
        V = compute_V(dataset, policy.get_q())
        Js.append(np.mean(J))
        ELs.append(np.mean(EL))
        Vs.append(np.mean(V))
        # wandb.log({'average_return': np.mean(J), 'episode_length': np.mean(EL), 'value_estimate': np.mean(V)})
        single_logger.epoch_info(ep+1, J=np.mean(J), EL=np.mean(EL), V=np.mean(V))
        policy.set_epsilon(epsilon)
    # wandb.finish()

    return Js, ELs, Vs


def seeding_experiment(pi, agent, mdp, params, approximator_params, num_run=25, num_epochs=100, n_steps=1000, n_episodes_test=5, exp_name = None, log_dir = None):
    seeds = np.random.randint(0, 1e5, size=(num_run,))  # list of seeds
    
    # pipeline
    out = Parallel(n_jobs=-1)(delayed(run)(
        pi, agent, mdp, params, approximator_params,
        num_epochs=num_epochs,
        n_steps=n_steps,
        n_episodes_test=n_episodes_test,
        seed=seeds[i],
        exp_name = exp_name,
        log_dir = log_dir,
        exp_id = i,
    ) for i in range(num_run))
    
    Js = np.array([o[0] for o in out])
    ELs = np.array([o[1] for o in out])
    Vs = np.array([o[2] for o in out])
    
    np.save(os.path.join(log_dir, "Js.npy"), Js)
    np.save(os.path.join(log_dir, "ELs.npy"), ELs)
    np.save(os.path.join(log_dir, "Vs.npy"), Vs)

    return Js, ELs, Vs

if __name__ == '__main__':

    args = argparser()

    num_run = args.n_exp
    num_epochs = args.n_epochs
    n_steps = args.n_steps
    n_episodes_test = args.n_episodes_test
    gamma = args.gamma
    learning_rate = args.lr

    policy_class = EpsGreedy
    n_approximators = 1
    optimizer = {'class': optim.RMSprop, 'params': {'lr':learning_rate, 'alpha': 0.95, 'centered': True, "eps": 0.01} }
    loss = F.smooth_l1_loss

    if args.agent_class == "DQN":
        agent_class = DQN        
    elif args.agent_class == "DQNwoReplayBuffer":
        agent_class = DQNwoReplayBuffer
    elif args.agent_class == "DoubleDQN":
        agent_class = DoubleDQN
    elif args.agent_class == "MaxminDQN":
        agent_class = MaxminDQN
        n_approximators = 2
    elif args.agent_class == "DoubleMaxminDQN":
        agent_class = DoubleMaxminDQN
        n_approximators = 2
    elif args.agent_class == "AveragedDQN":
        agent_class = AveragedDQN
        n_approximators = 2
    elif args.agent_class == "NaiveDQN":
        agent_class = NaiveDQN
    else:
        raise NotImplementedError

    params = {
        'eps': args.eps,
        'final_eps': args.final_eps,
        'eps_test': args.final_eps,
        'initial_replay_size': args.initial_replay_size,
        'max_replay_size': args.max_replay_size,
        'batch_size': args.batch_size,
        'target_update_frequency': args.target_update_frequency,
        'exploration_steps': args.exploration_steps,
        'train_frequency': args.train_frequency,
        'n_approximators': n_approximators,
    }

    env_name = args.env_name
    exp_name = "%s_%s"%(env_name,agent_class.__name__) if args.exp_name is None else args.exp_name

    log_dir = os.path.join("logs", env_name, agent_class.__name__)
    os.makedirs(log_dir, exist_ok=True)

    logger = Logger(exp_name, results_dir=log_dir, log_console=True, use_timestamp=args.use_timestamp)
    logger.strong_line()
    logger.info('Experiment Algorithm: ' + agent_class.__name__)
    log_dir = logger.path

    # mdp
    mdp = MinAtar(env_name, gamma=gamma)

    # network
    if args.network == "QConvNetwork":
        network = QConvNetwork
    else:
        raise NotImplementedError
    
    # Approximator
    approximator_params = dict(
        network = network,
        loss=loss,
        input_shape=mdp.info.observation_space.shape,
        output_shape=(mdp.info.action_space.n,),
        n_actions=mdp.info.action_space.n,
        n_features=args.n_features,
        optimizer = optimizer,
        use_cuda=args.use_cuda,
    )


    Js, ELs, Vs = seeding_experiment( policy_class,
                                agent_class,
                                mdp,
                                params, 
                                approximator_params, 
                                num_run=num_run, 
                                num_epochs=num_epochs, 
                                n_steps=n_steps, 
                                n_episodes_test=n_episodes_test,
                                exp_name=exp_name,
                                log_dir = log_dir
                                )
