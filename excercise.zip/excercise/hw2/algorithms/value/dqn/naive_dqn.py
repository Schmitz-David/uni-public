# import neccessary modules

class NaiveDQN:
    pass
    