# import neccessary modules

class DoubleMaxminDQN:
    pass