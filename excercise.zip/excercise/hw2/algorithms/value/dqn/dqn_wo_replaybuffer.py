# import neccessary modules

class DQNwoReplayBuffer:
    pass
    